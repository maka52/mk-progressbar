fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'Maka52'
description 'Custom Progress Bar!'
version '1.0.0'

ui_page 'html/index.html'

client_script 'client.lua'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
